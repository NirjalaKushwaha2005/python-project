# Week 3 — Python & Data Wrangling (VS Code Version)

## Assignment
**Clean a messy dataset in Pandas — handle missing values, filter rows, and create new columns.**

This is a VS Code-friendly Python project. It uses a normal `.py` file and does not require Jupyter Notebook.

## Requirements
- Python 3
- pandas
- numpy
- matplotlib

## Project structure

```text
week3_pandas_project_vscode/
├── data/
│   ├── raw_exercise_data.csv
│   ├── cleaned_exercise_data.csv       # generated when script runs
│   ├── high_calorie_workouts.csv       # generated when script runs
│   └── high_pulse_workouts.csv         # generated when script runs
├── visualizations/
│   ├── duration_distribution.png       # generated when script runs
│   ├── duration_vs_calories.png
│   ├── average_calories_by_duration.png
│   └── workout_intensity.png
├── week3_data_wrangling.py
├── README.md
└── requirements.txt
```

## How to run in VS Code

1. Extract the ZIP file.
2. Open the extracted `week3_pandas_project_vscode` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Install the required libraries:

   ```bash
   python -m pip install -r requirements.txt
   ```

5. Run the script from the project root:

   ```bash
   python week3_data_wrangling.py
   ```

   If `python` is not recognized on Windows, try:

   ```bash
   py week3_data_wrangling.py
   ```

## What the code does

1. Reads the original CSV with Pandas.
2. Displays the first rows, dataset information, and missing-value counts.
3. Cleans inconsistent formatting in the `Date` column and converts it to datetime.
4. Fills missing `Date` data using interpolation.
5. Fills missing `Calories` values with the median.
6. Flags a suspicious 450-minute duration rather than silently changing the original value; flagged outliers are excluded from the analysis dataset.
7. Removes duplicate records.
8. Creates `Month`, `Calories_per_Minute`, `Pulse_Range`, and `Workout_Intensity`.
9. Filters workouts with `Calories >= 300` and `Pulse >= 105`.
10. Saves cleaned/filtered CSV files and four charts.

## Important note about the data

The raw dataset is preserved in `data/raw_exercise_data.csv`. The script does not overwrite it. The 450-minute duration is treated as a suspicious outlier because the other durations are between 30 and 60 minutes; review the source if you need to confirm the correct value.

## Assignment requirements covered

- **Handle missing values:** yes
- **Filter rows:** yes
- **Create new columns:** yes
- **Pandas data cleaning:** yes
