"""
Week 3 Python & Data Wrangling Project
Assignment: Clean a messy dataset in Pandas — handle missing values,
filter rows, and create new columns.

Run this file from the project root in VS Code:
    python week3_data_wrangling.py
"""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Project paths
PROJECT_DIR = Path(__file__).resolve().parent
DATA_DIR = PROJECT_DIR / "data"
OUTPUT_DIR = PROJECT_DIR / "visualizations"
OUTPUT_DIR.mkdir(exist_ok=True)

INPUT_FILE = DATA_DIR / "raw_exercise_data.csv"
CLEANED_FILE = DATA_DIR / "cleaned_exercise_data.csv"
HIGH_CALORIE_FILE = DATA_DIR / "high_calorie_workouts.csv"
HIGH_PULSE_FILE = DATA_DIR / "high_pulse_workouts.csv"

# 1. Read the messy CSV file
df = pd.read_csv(INPUT_FILE)

print("=" * 60)
print("WEEK 3: PYTHON & DATA WRANGLING")
print("=" * 60)

# 2. Inspect the data
print("\\nFirst five rows:")
print(df.head())

print("\\nDataset information:")
df.info()

print("\\nMissing values before cleaning:")
print(df.isnull().sum())

# 3. Clean the Date column (remove surrounding quote marks)
date_text = (
    df["Date"].astype("string")
    .str.strip()
    .str.strip("'")
    .str.strip('"')
)

# Convert compact YYYYMMDD strings into YYYY/MM/DD, when present
date_text = date_text.where(
    ~date_text.str.fullmatch(r"\\d{8}", na=False),
    date_text.str.replace(
        r"(\\d{4})(\\d{2})(\\d{2})", r"\\1/\\2/\\3", regex=True
    ),
)

df["Date"] = pd.to_datetime(date_text, errors="coerce")

# Fill the missing date by interpolation because the records are sequential
df["Date"] = df["Date"].interpolate(method="linear")

# 4. Handle missing Calories with the median
median_calories = df["Calories"].median()
df["Calories"] = df["Calories"].fillna(median_calories)

# 5. Detect suspicious duration values
# The dataset has a 450-minute value, while typical values are 30–60 minutes.
df["Duration_Outlier"] = df["Duration"] > 120
outliers = df[df["Duration_Outlier"]].copy()

print("\\nSuspicious duration records (reviewed, not silently altered):")
if outliers.empty:
    print("No suspicious duration records found.")
else:
    print(outliers[["Duration", "Date", "Pulse", "Maxpulse", "Calories"]])

# Exclude flagged duration outliers from analysis, preserving the raw CSV.
clean_df = df.loc[~df["Duration_Outlier"]].copy()

# 6. Remove duplicate records
rows_before_duplicates = len(clean_df)
clean_df = clean_df.drop_duplicates().reset_index(drop=True)
duplicates_removed = rows_before_duplicates - len(clean_df)

# 7. Create new columns
clean_df["Month"] = clean_df["Date"].dt.strftime("%Y-%m")
clean_df["Calories_per_Minute"] = (
    clean_df["Calories"] / clean_df["Duration"]
).round(2)
clean_df["Pulse_Range"] = clean_df["Maxpulse"] - clean_df["Pulse"]

clean_df["Workout_Intensity"] = np.select(
    [
        clean_df["Pulse"] < 100,
        clean_df["Pulse"].between(100, 110),
        clean_df["Pulse"] > 110,
    ],
    ["Low", "Moderate", "High"],
    default="Unknown",
)

# 8. Filter rows
high_calorie = clean_df[clean_df["Calories"] >= 300].copy()
high_pulse = clean_df[clean_df["Pulse"] >= 105].copy()

# 9. Save processed datasets
clean_df.to_csv(CLEANED_FILE, index=False)
high_calorie.to_csv(HIGH_CALORIE_FILE, index=False)
high_pulse.to_csv(HIGH_PULSE_FILE, index=False)

# 10. Basic analysis
print("\\nCleaning summary:")
print(f"Rows in original dataset: {len(df)}")
print(f"Duration outliers flagged: {len(outliers)}")
print(f"Duplicate rows removed: {duplicates_removed}")
print(f"Rows in cleaned dataset: {len(clean_df)}")
print(f"Median used for missing Calories: {median_calories}")

print("\\nMissing values after cleaning:")
print(clean_df.isnull().sum())

print("\\nAverage workout duration:", round(clean_df["Duration"].mean(), 2), "minutes")
print("Average calories burned:", round(clean_df["Calories"].mean(), 2))

print("\\nWorkouts with Calories >= 300:")
print(high_calorie)

print("\\nWorkouts with Pulse >= 105:")
print(high_pulse)

# 11. Create and save visualizations
plt.figure(figsize=(9, 5))
plt.hist(clean_df["Duration"], bins=6, edgecolor="black")
plt.title("Distribution of Workout Duration")
plt.xlabel("Duration (minutes)")
plt.ylabel("Number of Workouts")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "duration_distribution.png", dpi=160)
plt.close()

plt.figure(figsize=(9, 5))
plt.scatter(clean_df["Duration"], clean_df["Calories"])
plt.title("Workout Duration vs Calories Burned")
plt.xlabel("Duration (minutes)")
plt.ylabel("Calories")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "duration_vs_calories.png", dpi=160)
plt.close()

average_calories = clean_df.groupby("Duration")["Calories"].mean().sort_index()
plt.figure(figsize=(9, 5))
plt.bar(average_calories.index.astype(str), average_calories.values)
plt.title("Average Calories by Workout Duration")
plt.xlabel("Duration (minutes)")
plt.ylabel("Average Calories")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "average_calories_by_duration.png", dpi=160)
plt.close()

intensity_counts = clean_df["Workout_Intensity"].value_counts()
plt.figure(figsize=(8, 5))
plt.bar(intensity_counts.index, intensity_counts.values)
plt.title("Workout Intensity Distribution")
plt.xlabel("Workout Intensity")
plt.ylabel("Number of Workouts")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "workout_intensity.png", dpi=160)
plt.close()

print("\\nSaved cleaned datasets in the data folder.")
print("Saved four charts in the visualizations folder.")
print("Project completed successfully.")
